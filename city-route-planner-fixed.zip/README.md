# City Route Planner – India
Dijkstra-based route planner (shortest path, reachable cities, trip optimizer, road-closure mode).

## Run
    cd backend
    npm install
    npm start          # http://localhost:5000
    npm test           # backend tests (Node 18+)

## Notes
- Time = distance / average speed (+ per-leg overhead for train/flight). Speeds are estimates.
- Walking uses the road network; train links are drawn as straight lines (no rail geometry).
- Road geometry comes from the public OSRM demo server; if it is down, straight lines are shown.
