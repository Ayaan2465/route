const express = require("express");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "..", "frontend")));

/* ------------------------------------------------------------------ */
/*  DATA                                                               */
/* ------------------------------------------------------------------ */

const cities = {
  Delhi: { lat: 28.6139, lng: 77.209 },
  Jaipur: { lat: 26.9124, lng: 75.7873 },
  Agra: { lat: 27.1767, lng: 78.0081 },
  Lucknow: { lat: 26.8467, lng: 80.9462 },
  Varanasi: { lat: 25.3176, lng: 82.9739 },
  Patna: { lat: 25.5941, lng: 85.1376 },
  Kolkata: { lat: 22.5726, lng: 88.3639 },
  Bhopal: { lat: 23.2599, lng: 77.4126 },
  Nagpur: { lat: 21.1458, lng: 79.0882 }, // was referenced by an edge but missing
  Ahmedabad: { lat: 23.0225, lng: 72.5714 },
  Surat: { lat: 21.1702, lng: 72.8311 },
  Mumbai: { lat: 18.9401, lng: 72.8354 },
  Pune: { lat: 18.5204, lng: 73.8567 },
  Lonavala: { lat: 18.7557, lng: 73.4091 },
  Hyderabad: { lat: 17.385, lng: 78.4867 },
  Bengaluru: { lat: 12.9716, lng: 77.5946 },
  Chennai: { lat: 13.0827, lng: 80.2707 }
};

// Road edges: [from, to, km, optionalAverageSpeedKmh]
// The optional speed is an ESTIMATE (expressway vs. ordinary highway) so that
// "optimize by time" can genuinely differ from "optimize by distance".
const drivingEdges = [
  ["Delhi", "Jaipur", 281, 62],
  ["Delhi", "Agra", 233, 85],        // Yamuna Expressway
  ["Delhi", "Lucknow", 555, 62],
  ["Jaipur", "Agra", 240, 55],
  ["Jaipur", "Ahmedabad", 664, 62],
  ["Jaipur", "Bhopal", 600, 55],
  ["Agra", "Lucknow", 337, 80],      // Agra-Lucknow Expressway
  ["Agra", "Bhopal", 465, 55],
  ["Lucknow", "Varanasi", 286, 55],
  ["Lucknow", "Patna", 528, 50],
  ["Varanasi", "Patna", 246, 50],
  ["Patna", "Kolkata", 581, 50],
  ["Bhopal", "Ahmedabad", 521, 60],
  ["Bhopal", "Hyderabad", 702, 60],
  ["Bhopal", "Nagpur", 347, 60],
  ["Nagpur", "Hyderabad", 500, 60],
  ["Ahmedabad", "Surat", 265, 75],
  ["Ahmedabad", "Mumbai", 524, 65],
  ["Surat", "Mumbai", 284, 65],
  ["Mumbai", "Pune", 149, 75],       // Mumbai-Pune Expressway
  ["Mumbai", "Lonavala", 83, 70],
  ["Lonavala", "Pune", 66, 65],
  ["Mumbai", "Hyderabad", 711, 60],
  ["Pune", "Hyderabad", 560, 60],
  ["Pune", "Bengaluru", 840, 62],
  ["Hyderabad", "Bengaluru", 574, 62],
  ["Hyderabad", "Chennai", 625, 60],
  ["Bengaluru", "Chennai", 346, 65],
  ["Kolkata", "Varanasi", 650, 50],
  ["Lucknow", "Bhopal", 510, 55]
];

// Rail edges: [from, to, km]
const trainEdges = [
  ["Delhi", "Agra", 200],
  ["Delhi", "Jaipur", 308],
  ["Delhi", "Lucknow", 512],
  ["Delhi", "Patna", 1000],
  ["Delhi", "Kolkata", 1450],
  ["Delhi", "Mumbai", 1385],
  ["Agra", "Varanasi", 500],
  ["Lucknow", "Varanasi", 270],
  ["Lucknow", "Patna", 510],
  ["Varanasi", "Patna", 230],
  ["Patna", "Kolkata", 550],
  ["Mumbai", "Pune", 192],
  ["Mumbai", "Ahmedabad", 491],
  ["Mumbai", "Hyderabad", 793],
  ["Mumbai", "Chennai", 1334],
  ["Ahmedabad", "Jaipur", 591],
  ["Ahmedabad", "Surat", 260],
  ["Pune", "Hyderabad", 664],
  ["Pune", "Bengaluru", 1165],
  ["Hyderabad", "Bengaluru", 794],
  ["Hyderabad", "Chennai", 796],
  ["Bengaluru", "Chennai", 362],
  ["Kolkata", "Bhopal", 1430],
  ["Bhopal", "Hyderabad", 864],
  ["Jaipur", "Bhopal", 703]
];

// Flights: only the PAIRS are listed. The distance is the real straight-line
// (great-circle) distance computed from the coordinates above, instead of the
// road distances that were wrongly reused before.
const flightPairs = [
  ["Delhi", "Mumbai"], ["Delhi", "Bengaluru"], ["Delhi", "Chennai"],
  ["Delhi", "Kolkata"], ["Delhi", "Hyderabad"], ["Delhi", "Ahmedabad"],
  ["Delhi", "Pune"], ["Delhi", "Jaipur"], ["Delhi", "Lucknow"],
  ["Delhi", "Patna"], ["Delhi", "Bhopal"], ["Delhi", "Nagpur"],
  ["Mumbai", "Bengaluru"], ["Mumbai", "Chennai"], ["Mumbai", "Kolkata"],
  ["Mumbai", "Hyderabad"], ["Mumbai", "Ahmedabad"], ["Mumbai", "Nagpur"],
  ["Bengaluru", "Chennai"], ["Bengaluru", "Hyderabad"], ["Bengaluru", "Kolkata"],
  ["Bengaluru", "Pune"], ["Bengaluru", "Nagpur"],
  ["Chennai", "Hyderabad"], ["Chennai", "Kolkata"],
  ["Kolkata", "Patna"],
  ["Hyderabad", "Ahmedabad"], ["Hyderabad", "Pune"], ["Hyderabad", "Nagpur"],
  ["Hyderabad", "Bhopal"],
  ["Ahmedabad", "Jaipur"]
];

function haversineKm(a, b) {
  const R = 6371;
  const toRad = (x) => (x * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

const flightEdges = flightPairs.map(([a, b]) => [
  a,
  b,
  Math.round(haversineKm(cities[a], cities[b]))
]);

/* ------------------------------------------------------------------ */
/*  MODES / GRAPHS                                                     */
/* ------------------------------------------------------------------ */

// speed       : default average km/h
// hopHours    : fixed overhead added for every leg (boarding, taxi, connection)
// ignoreEdgeSpeed : walking is always 5 km/h whatever the road type
const MODES = {
  driving: { speed: 60, hopHours: 0, label: "road" },
  walking: { speed: 5, hopHours: 0, label: "walking", ignoreEdgeSpeed: true },
  train: { speed: 70, hopHours: 0.25, label: "railway" },
  flight: { speed: 750, hopHours: 1.5, label: "airport" }
};

const edgeSource = {
  driving: drivingEdges,
  walking: drivingEdges, // there is no separate footpath data: walking uses the road network
  train: trainEdges,
  flight: flightEdges
};

function buildGraph(edges, mode) {
  const cfg = MODES[mode];
  const graph = {};
  for (const c in cities) graph[c] = [];
  for (const [a, b, km, edgeSpeed] of edges) {
    if (!graph[a] || !graph[b]) {
      // fail fast instead of silently dropping data (the old "Nagpur" bug)
      throw new Error(`Edge ${a}-${b} (${mode}) refers to a city that is not defined.`);
    }
    const speed = cfg.ignoreEdgeSpeed ? cfg.speed : edgeSpeed || cfg.speed;
    const hours = km / speed + cfg.hopHours;
    graph[a].push({ city: b, dist: km, hours });
    graph[b].push({ city: a, dist: km, hours });
  }
  return graph;
}

const graphs = {};
const supported = {}; // mode -> Set of cities that have at least one connection
for (const mode of Object.keys(MODES)) {
  graphs[mode] = buildGraph(edgeSource[mode], mode);
  supported[mode] = new Set(Object.keys(graphs[mode]).filter((c) => graphs[mode][c].length > 0));
}

function getConnections(mode) {
  return edgeSource[mode].map(([from, to, dist]) => ({ from, to, dist }));
}

/* ------------------------------------------------------------------ */
/*  DATA STRUCTURES / ALGORITHMS                                       */
/* ------------------------------------------------------------------ */

class MinHeap {
  constructor() {
    this.heap = [];
  }
  push(item) {
    this.heap.push(item);
    this._bubbleUp(this.heap.length - 1);
  }
  pop() {
    if (this.heap.length === 0) return undefined;
    const top = this.heap[0];
    const last = this.heap.pop();
    if (this.heap.length > 0) {
      this.heap[0] = last;
      this._sinkDown(0);
    }
    return top;
  }
  _bubbleUp(i) {
    while (i > 0) {
      const parent = Math.floor((i - 1) / 2);
      if (this.heap[parent].cost > this.heap[i].cost) {
        [this.heap[parent], this.heap[i]] = [this.heap[i], this.heap[parent]];
        i = parent;
      } else break;
    }
  }
  _sinkDown(i) {
    const n = this.heap.length;
    while (true) {
      const left = 2 * i + 1;
      const right = 2 * i + 2;
      let smallest = i;
      if (left < n && this.heap[left].cost < this.heap[smallest].cost) smallest = left;
      if (right < n && this.heap[right].cost < this.heap[smallest].cost) smallest = right;
      if (smallest === i) break;
      [this.heap[smallest], this.heap[i]] = [this.heap[i], this.heap[smallest]];
      i = smallest;
    }
  }
  isEmpty() {
    return this.heap.length === 0;
  }
}

// metric: "distance" (km) or "time" (hours). Both come from the edge itself,
// so time-optimal and distance-optimal routes can really differ.
function dijkstra(graph, start, end, closedSet, metric) {
  const dist = {};
  const prev = {};
  const visited = {};
  for (const c in graph) {
    dist[c] = Infinity;
    prev[c] = null;
  }
  dist[start] = 0;
  const pq = new MinHeap();
  pq.push({ cost: 0, city: start });
  while (!pq.isEmpty()) {
    const { city: u } = pq.pop();
    if (visited[u]) continue;
    visited[u] = true;
    if (end && u === end) break;
    for (const edge of graph[u]) {
      const v = edge.city;
      if (closedSet[u + "|" + v]) continue;
      const weight = metric === "time" ? edge.hours : edge.dist;
      const nd = dist[u] + weight;
      if (nd < dist[v]) {
        dist[v] = nd;
        prev[v] = u;
        pq.push({ cost: nd, city: v });
      }
    }
  }
  return { dist, prev };
}

function buildPath(prev, start, end) {
  if (start !== end && prev[end] === null) return null;
  const path = [];
  let cur = end;
  while (cur !== null) {
    path.unshift(cur);
    cur = prev[cur];
  }
  return path[0] === start ? path : null;
}

// total km and total hours of a path (uses each edge's own time)
function pathMetrics(path, graph) {
  let km = 0;
  let hours = 0;
  for (let i = 0; i < path.length - 1; i++) {
    const edge = graph[path[i]].find((e) => e.city === path[i + 1]);
    km += edge.dist;
    hours += edge.hours;
  }
  return { km, hours };
}

function formatTime(hours, mode) {
  const totalMinutes = Math.round(hours * 60); // round first -> never "1h 60m"
  if (mode === "walking") {
    const days = Math.floor(totalMinutes / (24 * 60));
    const remH = ((totalMinutes % (24 * 60)) / 60).toFixed(1);
    return days > 0 ? `${days}d ${remH}h` : `${remH}h`;
  }
  return `${Math.floor(totalMinutes / 60)}h ${totalMinutes % 60}m`;
}

/* ------------------------------------------------------------------ */
/*  VALIDATION HELPERS                                                 */
/* ------------------------------------------------------------------ */

const hasOwn = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);

function parseClosed(list) {
  if (list === undefined || list === null) return { set: {} };
  if (!Array.isArray(list) || list.length > 200) {
    return { error: "closedConnections must be an array of at most 200 items." };
  }
  const set = {};
  for (const c of list) {
    if (!c || typeof c.from !== "string" || typeof c.to !== "string") {
      return { error: "Each closed connection needs string 'from' and 'to'." };
    }
    set[c.from + "|" + c.to] = true;
    set[c.to + "|" + c.from] = true;
  }
  return { set };
}

// Shared by every POST endpoint: validates mode and closures.
function parseCommon(body) {
  const mode = body.mode === undefined ? "driving" : body.mode;
  if (typeof mode !== "string" || !hasOwn(MODES, mode)) {
    return { error: `Invalid mode. Use one of: ${Object.keys(MODES).join(", ")}.` };
  }
  const closed = parseClosed(body.closedConnections);
  if (closed.error) return { error: closed.error };
  return { mode, graph: graphs[mode], closedSet: closed.set };
}

function checkCity(name, mode, label) {
  if (typeof name !== "string" || !hasOwn(cities, name)) return `Invalid ${label} city.`;
  if (!supported[mode].has(name)) {
    return `${name} has no ${MODES[mode].label} connections in ${mode} mode.`;
  }
  return null;
}

/* ------------------------------------------------------------------ */
/*  ROUTES                                                             */
/* ------------------------------------------------------------------ */

app.get("/api/cities", (req, res) => {
  res.json(Object.keys(cities).map((name) => ({ name, lat: cities[name].lat, lng: cities[name].lng })));
});

app.get("/api/connections", (req, res) => {
  const mode = req.query.mode || "driving";
  if (!hasOwn(MODES, mode)) return res.status(400).json({ error: "Invalid mode." });
  res.json(getConnections(mode));
});

// Road geometry proxy (OSRM) with a small bounded cache.
const routeGeometryCache = new Map();
const CACHE_LIMIT = 200;
const COORDS_RE = /^-?\d{1,3}(\.\d+)?,-?\d{1,3}(\.\d+)?(;-?\d{1,3}(\.\d+)?,-?\d{1,3}(\.\d+)?){1,24}$/;

app.get("/api/route-geometry", async (req, res) => {
  const { coords, mode } = req.query;
  if (typeof coords !== "string" || !COORDS_RE.test(coords)) {
    return res.status(400).json({ error: "coords must look like 'lng,lat;lng,lat' (2-25 points)." });
  }
  const profile = mode === "walking" ? "walking" : "driving";
  const cacheKey = `${profile}:${coords}`;
  if (routeGeometryCache.has(cacheKey)) return res.json(routeGeometryCache.get(cacheKey));
  try {
    const url =
      `https://router.project-osrm.org/route/v1/${profile}/${coords}` +
      `?overview=full&geometries=geojson&alternatives=true`;
    const response = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!response.ok) throw new Error("OSRM returned status " + response.status);
    const data = await response.json();
    if (data.code !== "Ok" || !data.routes || data.routes.length === 0) {
      return res.status(404).json({ error: "No route found" });
    }
    const result = {
      routes: data.routes.slice(0, 2).map((r) => ({
        coordinates: r.geometry.coordinates.map((pt) => [pt[1], pt[0]]),
        distance: Math.round(r.distance / 1000),
        duration: Math.round(r.duration / 60)
      }))
    };
    if (routeGeometryCache.size >= CACHE_LIMIT) {
      routeGeometryCache.delete(routeGeometryCache.keys().next().value); // drop oldest
    }
    routeGeometryCache.set(cacheKey, result);
    return res.json(result);
  } catch (err) {
    return res.status(502).json({ error: "Failed to fetch road geometry", details: err.message });
  }
});

app.post("/api/shortest-path", (req, res) => {
  const body = req.body || {};
  const common = parseCommon(body);
  if (common.error) return res.status(400).json({ error: common.error });
  const { mode, graph, closedSet } = common;
  const { source, destination } = body;
  const metric = body.optimizeBy === "time" ? "time" : "distance";

  if (!source || !destination) {
    return res.status(400).json({ error: "Source and destination required." });
  }
  const err = checkCity(source, mode, "source") || checkCity(destination, mode, "destination");
  if (err) return res.status(400).json({ error: err });
  if (source === destination) {
    return res.status(400).json({ error: "Source and destination must be different." });
  }

  const result = dijkstra(graph, source, destination, closedSet, metric);
  const path = buildPath(result.prev, source, destination);
  if (!path) {
    return res.status(404).json({ error: "No path found between selected cities for this mode." });
  }
  const m = pathMetrics(path, graph);
  res.json({
    path,
    optimizeBy: metric,
    totalDistance: Math.round(m.km),
    totalTime: formatTime(m.hours, mode),
    totalTimeHours: m.hours
  });
});

app.post("/api/reachable", (req, res) => {
  const body = req.body || {};
  const common = parseCommon(body);
  if (common.error) return res.status(400).json({ error: common.error });
  const { mode, graph, closedSet } = common;
  const { source } = body;

  const err = checkCity(source, mode, "source");
  if (err) return res.status(400).json({ error: err });

  const budget = Number(body.budget);
  if (!Number.isFinite(budget) || budget <= 0) {
    return res.status(400).json({ error: "Budget must be a number greater than 0." });
  }
  const metric = body.budgetType === "time" ? "time" : "distance";

  const result = dijkstra(graph, source, null, closedSet, metric);
  const reachable = [];
  for (const city in result.dist) {
    if (city === source) continue;
    const cost = result.dist[city];
    if (cost === Infinity || cost > budget) continue;
    const path = buildPath(result.prev, source, city);
    const m = pathMetrics(path, graph);
    reachable.push({
      city,
      distance: Math.round(m.km),
      time: formatTime(m.hours, mode),
      timeHours: m.hours,
      path,
      cost
    });
  }
  reachable.sort((a, b) => a.cost - b.cost); // sorted by the metric the user chose
  res.json({ reachable: reachable.map(({ cost, ...rest }) => rest) });
});

function permutations(arr) {
  if (arr.length <= 1) return [arr];
  const out = [];
  for (let i = 0; i < arr.length; i++) {
    const rest = arr.slice(0, i).concat(arr.slice(i + 1));
    for (const p of permutations(rest)) out.push([arr[i], ...p]);
  }
  return out;
}

app.post("/api/trip-optimizer", (req, res) => {
  const body = req.body || {};
  const common = parseCommon(body);
  if (common.error) return res.status(400).json({ error: common.error });
  const { mode, graph, closedSet } = common;
  const { start } = body;
  const metric = body.optimizeBy === "time" ? "time" : "distance";
  const returnToStart = body.returnToStart === true;

  const startErr = checkCity(start, mode, "start");
  if (startErr) return res.status(400).json({ error: startErr });

  const toVisit = body.cities;
  if (!Array.isArray(toVisit) || toVisit.length < 1 || toVisit.length > 5) {
    return res.status(400).json({ error: "Select between 1 and 5 cities to visit." });
  }
  if (new Set(toVisit).size !== toVisit.length) {
    return res.status(400).json({ error: "Each city can be listed only once." });
  }
  if (toVisit.includes(start)) {
    return res.status(400).json({ error: "The start city cannot also be in the visit list." });
  }
  for (const c of toVisit) {
    const e = checkCity(c, mode, "visit");
    if (e) return res.status(400).json({ error: e });
  }

  // Dijkstra from every node of interest -> pairwise cost + path table
  const nodes = [start, ...toVisit];
  const pairCost = {};
  const pairPath = {};
  for (const from of nodes) {
    const r = dijkstra(graph, from, null, closedSet, metric);
    for (const to of nodes) {
      if (from === to) continue;
      pairCost[from + "|" + to] = r.dist[to];
      pairPath[from + "|" + to] = buildPath(r.prev, from, to);
    }
  }

  // Brute force over visiting orders (at most 5! = 120)
  let bestCost = Infinity;
  let bestOrder = null;
  for (const order of permutations(toVisit)) {
    const stops = returnToStart ? [start, ...order, start] : [start, ...order];
    let total = 0;
    let ok = true;
    for (let i = 0; i < stops.length - 1; i++) {
      const k = stops[i] + "|" + stops[i + 1];
      if (pairCost[k] === Infinity || !pairPath[k]) { ok = false; break; }
      total += pairCost[k];
    }
    if (ok && total < bestCost) {
      bestCost = total;
      bestOrder = stops;
    }
  }
  if (!bestOrder) {
    return res.status(404).json({ error: "No valid trip found. Some cities may be unreachable." });
  }

  const segments = [];
  const fullPath = [start];
  let km = 0;
  let hours = 0;
  for (let i = 0; i < bestOrder.length - 1; i++) {
    const seg = pairPath[bestOrder[i] + "|" + bestOrder[i + 1]];
    segments.push({ from: bestOrder[i], to: bestOrder[i + 1], path: seg });
    fullPath.push(...seg.slice(1));
    const m = pathMetrics(seg, graph);
    km += m.km;
    hours += m.hours;
  }

  res.json({
    bestOrder,
    returnToStart,
    totalDistance: Math.round(km),
    totalTime: formatTime(hours, mode),
    totalTimeHours: hours,
    segments,
    fullPath
  });
});

/* ------------------------------------------------------------------ */
/*  ERROR HANDLING + START                                             */
/* ------------------------------------------------------------------ */

app.use((err, req, res, next) => {
  if (err && err.type === "entity.parse.failed") {
    return res.status(400).json({ error: "Request body is not valid JSON." });
  }
  if (err && err.type === "entity.too.large") {
    return res.status(413).json({ error: "Request body too large." });
  }
  console.error(err);
  res.status(500).json({ error: "Internal server error." });
});

module.exports = app; // exported so tests can start it on a random port

if (require.main === module) {
  const PORT = process.env.PORT || 5000;
  app.listen(PORT, () => {
    console.log("City Route Planner backend running on port " + PORT);
    console.log("Open the app at: http://localhost:" + PORT);
  });
}
