// Run with:  npm test      (needs Node 18+)
const test = require("node:test");
const assert = require("node:assert");
const app = require("./server");

let server, base;
test.before(() => new Promise((resolve) => {
  server = app.listen(0, () => { base = "http://localhost:" + server.address().port; resolve(); });
}));
test.after(() => server.close());

const post = (url, body) =>
  fetch(base + url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
    .then(async (r) => ({ status: r.status, data: await r.json() }));

test("time and distance optimisation can give different routes", async () => {
  const d = await post("/api/shortest-path", { source: "Delhi", destination: "Lucknow", mode: "driving", optimizeBy: "distance" });
  const t = await post("/api/shortest-path", { source: "Delhi", destination: "Lucknow", mode: "driving", optimizeBy: "time" });
  assert.deepStrictEqual(d.data.path, ["Delhi", "Lucknow"]);
  assert.deepStrictEqual(t.data.path, ["Delhi", "Agra", "Lucknow"]); // longer but faster (expressways)
  assert.ok(t.data.totalDistance > d.data.totalDistance);
  assert.ok(t.data.totalTimeHours < d.data.totalTimeHours);
});

test("walking always uses 5 km/h", async () => {
  const r = await post("/api/shortest-path", { source: "Delhi", destination: "Agra", mode: "walking" });
  assert.ok(Math.abs(r.data.totalTimeHours - 233 / 5) < 1e-9);
});

test("flight legs include overhead and use great-circle distance", async () => {
  const r = await post("/api/shortest-path", { source: "Delhi", destination: "Mumbai", mode: "flight" });
  assert.deepStrictEqual(r.data.path, ["Delhi", "Mumbai"]);
  assert.ok(r.data.totalDistance > 1100 && r.data.totalDistance < 1200);
  assert.ok(r.data.totalTimeHours > r.data.totalDistance / 750 + 1.4);
});

test("Bhopal-Nagpur road exists now", async () => {
  const r = await post("/api/shortest-path", { source: "Bhopal", destination: "Nagpur", mode: "driving" });
  assert.strictEqual(r.data.totalDistance, 347);
});

test("invalid mode is a 400 on every endpoint (used to crash)", async () => {
  for (const [url, body] of [
    ["/api/shortest-path", { source: "Delhi", destination: "Agra" }],
    ["/api/reachable", { source: "Delhi", budget: 500 }],
    ["/api/trip-optimizer", { start: "Delhi", cities: ["Agra"] }]
  ]) {
    const r = await post(url, { ...body, mode: "bike" });
    assert.strictEqual(r.status, 400, url);
  }
  const g = await fetch(base + "/api/connections?mode=constructor");
  assert.strictEqual(g.status, 400);
});

test("cities without a connection in that mode are rejected everywhere", async () => {
  const a = await post("/api/reachable", { source: "Lonavala", mode: "train", budget: 2000 });
  assert.strictEqual(a.status, 400);
  const b = await post("/api/shortest-path", { source: "Surat", destination: "Delhi", mode: "flight" });
  assert.strictEqual(b.status, 400);
});

test("reachable validates the budget and respects time budgets", async () => {
  assert.strictEqual((await post("/api/reachable", { source: "Delhi", budget: -5 })).status, 400);
  const r = await post("/api/reachable", { source: "Delhi", mode: "driving", budgetType: "time", budget: 4 });
  assert.ok(r.data.reachable.length > 0);
  assert.ok(r.data.reachable.every((c) => c.timeHours <= 4));
});

test("trip optimiser: validation", async () => {
  assert.strictEqual((await post("/api/trip-optimizer", { start: "Delhi", cities: ["Jaipur", "Jaipur"] })).status, 400);
  assert.strictEqual((await post("/api/trip-optimizer", { start: "Delhi", cities: ["Delhi"] })).status, 400);
  assert.strictEqual((await post("/api/trip-optimizer", { start: "Delhi", cities: ["Atlantis"] })).status, 400);
  assert.strictEqual((await post("/api/trip-optimizer", { start: "Delhi", cities: "Agra" })).status, 400);
});

test("trip optimiser: open trip vs round trip", async () => {
  const open = await post("/api/trip-optimizer", { start: "Delhi", cities: ["Jaipur", "Agra"] });
  const round = await post("/api/trip-optimizer", { start: "Delhi", cities: ["Jaipur", "Agra"], returnToStart: true });
  assert.notStrictEqual(open.data.bestOrder.at(-1), "Delhi");
  assert.strictEqual(round.data.bestOrder.at(-1), "Delhi");
  assert.strictEqual(round.data.bestOrder[0], "Delhi");
  assert.ok(round.data.totalDistance > open.data.totalDistance);
});

test("closed roads are avoided and can disconnect cities", async () => {
  const r = await post("/api/shortest-path", {
    source: "Delhi", destination: "Lucknow", mode: "driving",
    closedConnections: [{ from: "Lucknow", to: "Delhi" }]
  });
  assert.deepStrictEqual(r.data.path, ["Delhi", "Agra", "Lucknow"]);
  const none = await post("/api/shortest-path", {
    source: "Delhi", destination: "Kolkata", mode: "driving",
    closedConnections: [{ from: "Patna", to: "Kolkata" }, { from: "Kolkata", to: "Varanasi" }]
  });
  assert.strictEqual(none.status, 404);
});

test("bad JSON and bad closures give 400, not a crash", async () => {
  const raw = await fetch(base + "/api/shortest-path", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{oops" });
  assert.strictEqual(raw.status, 400);
  const r = await post("/api/shortest-path", { source: "Delhi", destination: "Agra", closedConnections: "all" });
  assert.strictEqual(r.status, 400);
});

test("route-geometry rejects malformed coords (no URL injection)", async () => {
  const r = await fetch(base + "/api/route-geometry?coords=" + encodeURIComponent("1,2;3,4/../../x"));
  assert.strictEqual(r.status, 400);
});
